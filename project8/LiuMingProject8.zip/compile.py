import py_compile as comp

comp.compile("vmtranslator.py")