Both programs should work normally.

Note: For Fill, if after filling/emptying the screen manipulating inputs does nothing, try clicking the "screen" and then pressing keys again.